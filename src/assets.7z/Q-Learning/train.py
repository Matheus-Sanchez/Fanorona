# ======================================================================
# Responsabilidade: Script para executar o treinamento do agente.
# Este script deve ser rodado separadamente, antes de jogar.
# ======================================================================


import time
from environment import FanoronaEnv
from agent import QLearningAgent

def train_agent(episodes=50000):
    env = FanoronaEnv()
    agent = QLearningAgent()
    
    # Tenta carregar uma política existente para continuar o treinamento
    agent.load_policy()

    start_time = time.time()

    for episode in range(episodes):
        state = env.reset()
        done = False
        player = 'v' # 'v' sempre começa
        turn = 0
        max_turns = 100 # Limite para evitar jogos infinitos

        while not done and turn < max_turns:
            state_list = list(map(list, state))
            
            # Pega as ações legais para o jogador atual
            legal_actions = env.get_legal_actions(state_list, player)
            
            # Se não há movimentos, o jogador perde. O loop do jogo terminará.
            if not legal_actions:
                break
                
            # Agente escolhe uma ação
            action = agent.choose_action(state_list, legal_actions)

            # Ambiente executa a ação
            next_state_list, reward, done = env.step(state_list, action, player)
            
            # O agente aprende com a transição
            opponent = 'b' if player == 'v' else 'v'
            next_legal_actions = env.get_legal_actions(next_state_list, opponent)
            agent.update(state_list, action, reward, next_state_list, next_legal_actions)
            
            state = env.get_state_tuple(next_state_list)
            player = opponent # Troca de turno
            turn += 1

        # Log de progresso e salvamento periódico
        if (episode + 1) % 100 == 0:
            end_time = time.time()
            print(f"Episódio: {episode + 1}/{episodes} | Duração dos últimos 100: {end_time - start_time:.2f}s")
            start_time = time.time()
        
        if (episode + 1) % 1000 == 0:
            agent.save_policy()

    print("Treinamento concluído!")
    agent.save_policy() # Salva a política final

if __name__ == '__main__':
    train_agent()