# ======================================================================
# Responsabilidade: Contém a classe do Agente Q-Learning, adaptada
# para usar dicionários em vez de arrays NumPy.
# ======================================================================

import numpy as np
import random
import pickle

class QLearningAgent:
    """
    Esta é a classe `Qlearning` do seu professor, mas adaptada para o Fanorona.
    - Usa dicionários para a Q-Table e Política, permitindo um número
      quase infinito de estados/ações.
    - O loop de treinamento é episódico (jogo a jogo).
    """
    def __init__(self, desconto=0.90, alpha=0.1, e=0.4):
        # [PROFESSOR] self.Q e self.PI agora são dicionários
        self.q_table = {}  # Q(s, a) -> valor
        self.policy = {}   # PI(s) -> melhor ação
        
        # [PROFESSOR] Parâmetros do seu exemplo
        self.desconto = desconto
        self.alpha = alpha
        self.e = e  # Epsilon: taxa de exploração

    def _get_state_key(self, state_list):
        """Converte o estado em uma chave de dicionário imutável."""
        return tuple(map(tuple, state_list))

    def _get_action_key(self, action):
        """Converte a ação (lista de tuplos) em uma chave imutável."""
        return tuple(map(tuple, action))

    def get_q_value(self, state_key, action_key):
        """Obtém um valor da Q-Table, retornando 0 se não existir."""
        return self.q_table.get(state_key, {}).get(action_key, 0.0)

    # [PROFESSOR] Equivalente a `sorteia_proxima_acao`
    def choose_action(self, state_list, legal_actions, is_training=True):
        """
        Escolhe uma ação usando a estratégia epsilon-greedy.
        - Com probabilidade 'e', escolhe uma ação aleatória (exploração).
        - Com probabilidade (1-e), escolhe a melhor ação conhecida (explotação).
        """
        if not legal_actions:
            return None

        state_key = self._get_state_key(state_list)

        # Exploração
        if is_training and random.uniform(0, 1) < self.e:
            return random.choice(legal_actions)
        
        # Explotação
        # [PROFESSOR] acao_politica = self.PI[estado]
        # Se já temos uma política para este estado, use-a.
        if state_key in self.policy:
            # Certifica-se de que a ação da política ainda é legal
            best_action_from_policy = list(map(tuple, self.policy[state_key]))
            if best_action_from_policy in legal_actions:
                return best_action_from_policy

        # Se não há política ou a política aponta para uma jogada ilegal,
        # encontra a melhor ação a partir da Q-Table.
        q_values = {self._get_action_key(a): self.get_q_value(state_key, self._get_action_key(a)) for a in legal_actions}
        
        if not q_values:
             return random.choice(legal_actions) # Fallback

        max_q = max(q_values.values())
        best_actions = [a for a, q in q_values.items() if q == max_q]
        
        # Desempacota a ação de volta para o formato de lista
        chosen_action_tuple = random.choice(best_actions)
        return list(map(list, chosen_action_tuple))

    # [PROFESSOR] Equivalente a `novo_q` e a linha de atualização do Q-value
    def update(self, state, action, reward, next_state, next_legal_actions):
        """Atualiza a Q-Table e a Política para um passo (s, a, r, s')."""
        state_key = self._get_state_key(state)
        action_key = self._get_action_key(action)
        next_state_key = self._get_state_key(next_state)

        # Pega o Q-valor antigo
        # [PROFESSOR] q_antigo = self.Q[estado][acao]
        old_value = self.get_q_value(state_key, action_key)

        # Calcula o melhor Q-valor para o próximo estado
        # [PROFESSOR] max_a = np.max(self.Q[proximo_estado])
        if not next_legal_actions:
            next_max_q = 0.0
        else:
            next_q_values = [self.get_q_value(next_state_key, self._get_action_key(a)) for a in next_legal_actions]
            next_max_q = max(next_q_values)
        
        # Calcula o novo valor Q
        # [PROFESSOR] Q(s,a) <= alpha * q_antigo + (1-alpha) * (recompensa + desconto * max_a)
        # A fórmula abaixo é matematicamente equivalente e mais comum
        new_value = old_value + self.alpha * (reward + self.desconto * next_max_q - old_value)

        # Atualiza a Q-Table
        if state_key not in self.q_table:
            self.q_table[state_key] = {}
        self.q_table[state_key][action_key] = new_value

        # Atualiza a política para o estado atual
        # [PROFESSOR] self.PI[estado] = np.argmax(self.Q[estado])
        current_best_action = max(self.q_table[state_key], key=self.q_table[state_key].get)
        self.policy[state_key] = current_best_action

    def save_policy(self, file_path='qlearning_policy.pkl'):
        """Salva a Q-Table e a política em um arquivo."""
        with open(file_path, 'wb') as f:
            pickle.dump({'q_table': self.q_table, 'policy': self.policy}, f)
        print(f"Política salva em {file_path}")

    def load_policy(self, file_path='qlearning_policy.pkl'):
        """Carrega a Q-Table e a política de um arquivo."""
        try:
            with open(file_path, 'rb') as f:
                data = pickle.load(f)
                self.q_table = data['q_table']
                self.policy = data['policy']
            print(f"Política carregada de {file_path}")
        except FileNotFoundError:
            print(f"Arquivo de política não encontrado em {file_path}. Começando com uma política vazia.")
