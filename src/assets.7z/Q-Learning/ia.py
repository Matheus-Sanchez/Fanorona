# ======================================================================
# Responsabilidade: Interface para o jogo usar a IA treinada.
# ======================================================================


from .agent import QLearningAgent

# Instancia global do agente para não precisar carregar o arquivo toda vez
q_agent = QLearningAgent()
q_agent.load_policy() # Carrega a política uma vez quando o módulo é importado

def escolher_movimento_qlearning(state, player):
    """
    Função chamada pelo `main.py` para obter a jogada da IA.
    Usa a política aprendida sem exploração.
    """
    legal_actions = generate_moves(state, player)
    if not legal_actions:
        return None
        
    # Chama choose_action com is_training=False para garantir que ele use a melhor jogada
    return q_agent.choose_action(state, legal_actions, is_training=False)
