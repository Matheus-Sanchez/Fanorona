# ======================================================================
# Responsabilidade: Define o ambiente do jogo Fanorona de uma forma que
# o agente de Q-Learning possa entender (estados, ações, recompensas).
# ======================================================================

from copy import deepcopy
from MiniMax.gerador_movimentos import generate_moves, aplicar_movimento

class FanoronaEnv:
    """
    Esta classe é o "problema" que a classe QLearning do seu professor precisa.
    Ela adapta o seu jogo Fanorona para a interface de um ambiente de
    Aprendizado por Reforço.
    """
    def __init__(self):
        self.initial_state = [
            ["v", "v", "v", "v", "v", "v", "v", "v", "v"],
            ["v", "v", "v", "v", "v", "v", "v", "v", "v"],
            ["v", "b", "v", "b", "-", "v", "b", "v", "b"],
            ["b", "b", "b", "b", "b", "b", "b", "b", "b"],
            ["b", "b", "b", "b", "b", "b", "b", "b", "b"]
        ]
        self.reset()

    def reset(self):
        """Reseta o ambiente para o estado inicial."""
        self.state = deepcopy(self.initial_state)
        return self.get_state_tuple()

    def get_state_tuple(self, state=None):
        """
        Converte o estado do tabuleiro (lista de listas) para um tuplo de tuplos.
        Isso é essencial porque dicionários (que usaremos para a Q-Table)
        precisam de chaves que não mudam (imutáveis), e tuplos são imutáveis.
        """
        target_state = state if state is not None else self.state
        return tuple(map(tuple, target_state))

    def get_legal_actions(self, state_list, player):
        """Retorna todas as ações legais para um jogador em um dado estado."""
        return generate_moves(state_list, player)

    def is_done(self, state_list, player):
        """
        Verifica se o jogo terminou.
        O jogo termina se um jogador não tiver peças ou não tiver movimentos.
        """
        opponent = 'b' if player == 'v' else 'v'
        
        player_pieces = sum(row.count(player) for row in state_list)
        opponent_pieces = sum(row.count(opponent) for row in state_list)

        if player_pieces == 0 or opponent_pieces == 0:
            return True

        player_moves = self.get_legal_actions(state_list, player)
        if not player_moves:
            return True
            
        return False

    def step(self, state_list, action, player):
        """
        Executa uma ação no ambiente.
        Isso é o equivalente a `problema.T` e `problema.R` do seu exemplo.
        Retorna: (proximo_estado, recompensa, finalizado)
        """
        opponent = 'b' if player == 'v' else 'v'
        
        # 1. Aplica o movimento para obter o próximo estado
        next_state_list, captured_pieces = aplicar_movimento(state_list, action, player)

        # 2. Calcula a recompensa
        reward = 0
        done = False
        
        # Verifica se o jogo acabou no próximo estado
        opponent_moves = self.get_legal_actions(next_state_list, opponent)
        
        # Se o oponente não tem mais movimentos, o jogador atual venceu.
        if not opponent_moves:
            reward = 100  # Recompensa alta por vitória
            done = True
        else:
            # Recompensa intermediária por capturar peças
            reward += len(captured_pieces) * 5
            # Pequena penalidade por movimento para incentivar jogos mais rápidos
            reward -= 1

        return (next_state_list, reward, done)
